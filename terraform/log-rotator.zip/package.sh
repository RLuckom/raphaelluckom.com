#!/bin/bash
zip -r log-rotator.zip .
mv log-rotator.zip ../terraform/.
